<?php
require 'config.php';
$user = require_login($db);
$pageTitle = "Ustawienia konta";
include 'includes/header.php';

// Obsługa zapisu
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $first = trim($_POST['first_name']);
    $last = trim($_POST['last_name']);
    $country = $_POST['country_code'];
    $phone = preg_replace('/\D/', '', $_POST['phone']);
    $address = trim($_POST['address']);
    $bio = trim($_POST['bio']);

    $avatarPath = $user['avatar'];
    if (!empty($_FILES['avatar']['name'])) {
        $uploadDir = 'uploads/avatars/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);
        $fileName = time().'_'.basename($_FILES['avatar']['name']);
        $target = $uploadDir.$fileName;
        if (move_uploaded_file($_FILES['avatar']['tmp_name'], $target)) {
            $avatarPath = $target;
        }
    }

    $stmt = $db->prepare("UPDATE users SET first_name=?, last_name=?, country_code=?, phone=?, address=?, avatar=?, bio=? WHERE email=?");
    $stmt->execute([$first, $last, $country, $phone, $address, $avatarPath, $bio, $user['email']]);
    header("Location: account.php?updated=1");
    exit;
}
?>

<section class="account-settings">
  <h1>Ustawienia konta</h1>

  <?php if (isset($_GET['updated'])): ?>
    <div class="alert-success">✅ Zapisano zmiany</div>
  <?php endif; ?>

  <form method="post" enctype="multipart/form-data">
    <div class="profile-header">
      <img src="<?= htmlspecialchars($user['avatar']) ?>" class="avatar">
      <div>
        <label for="avatar">Zmień avatar:</label>
        <input type="file" name="avatar" accept="image/*">
      </div>
    </div>

    <label>Imię</label>
    <input type="text" name="first_name" value="<?= htmlspecialchars($user['first_name']) ?>" required>

    <label>Nazwisko</label>
    <input type="text" name="last_name" value="<?= htmlspecialchars($user['last_name']) ?>" required>

    <label>Kierunkowy i numer telefonu</label>
    <div class="phone-input-wrapper">
      <select name="country_code" required>
        <?php
        $codes = [
          '+48' => '🇵🇱 +48',
          '+49' => '🇩🇪 +49',
          '+44' => '🇬🇧 +44',
          '+420' => '🇨🇿 +420',
          '+421' => '🇸🇰 +421',
          '+33' => '🇫🇷 +33',
          '+39' => '🇮🇹 +39',
          '+1'  => '🇺🇸 +1'
        ];
        foreach ($codes as $c => $n) {
          $sel = ($user['country_code'] === $c) ? 'selected' : '';
          echo "<option value='$c' $sel>$n</option>";
        }
        ?>
      </select>
      <input type="text" id="phone" name="phone" value="<?= htmlspecialchars($user['phone']) ?>" maxlength="11" required>
    </div>

    <label>Adres zamieszkania</label>
    <input type="text" name="address" value="<?= htmlspecialchars($user['address']) ?>" required>

    <label>Opis konta (bio)</label>
    <textarea name="bio" rows="3"><?= htmlspecialchars($user['bio']) ?></textarea>

    <button type="submit">Zapisz zmiany</button>
  </form>
</section>

<?php include 'includes/footer.php'; ?>
