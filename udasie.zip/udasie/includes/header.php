<?php
if (!isset($pageTitle)) $pageTitle = "AutoPart";
?>
<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= htmlspecialchars($pageTitle) ?></title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>

<nav>
  <img src="logo.png" alt="AutoPart Battery" class="logo">
  <div class="nav-links">
    <a href="dashboard.php"><i class="fa-solid fa-gauge"></i> Panel</a>
    <a href="browse.php"><i class="fa-solid fa-newspaper"></i> Przeglądanie</a>
    <a href="garage.php"><i class="fa-solid fa-car"></i> Garaż</a>
    <a href="messages.php"><i class="fa-solid fa-envelope"></i> Wiadomości</a>
    <a href="notifications.php"><i class="fa-solid fa-bell"></i> Powiadomienia</a>
    <a href="users.php"><i class="fa-solid fa-users"></i> Użytkownicy</a>

    <?php if (isset($user) && $user['role'] === 'admin'): ?>
      <a href="admin.php" class="admin-link">
        <i class="fa-solid fa-shield-halved"></i> Admin
      </a>
    <?php endif; ?>

    <a href="account.php"><i class="fa-solid fa-gear"></i> Konto</a>

    <button id="theme-toggle" class="theme-toggle" title="Zmień tryb">
      <i class="fa-solid fa-moon"></i>
    </button>

    <form method="post" action="logout.php" style="display:inline;">
      <button type="submit" class="nav-logout">
        <i class="fa-solid fa-right-from-bracket"></i> Wyloguj
      </button>
    </form>
  </div>
</nav>

<main>
