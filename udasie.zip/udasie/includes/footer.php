    </main>
<footer>© <?= date('Y') ?> AutoPart Battery Community</footer>
<script src="assets/script.js"></script>
</body>
</html>
