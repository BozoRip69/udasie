<?php
require 'config.php';
$user = require_login($db);
$pageTitle = "Wiadomości";
include 'includes/header.php';

// Pobierz listę użytkowników (bez siebie)
$usersStmt = $db->prepare("SELECT id, first_name, last_name, avatar FROM users WHERE id != ?");
$usersStmt->execute([$user['id']]);
$users = $usersStmt->fetchAll(PDO::FETCH_ASSOC);
?>

<section class="messages">
  <h1>Wiadomości</h1>
  <div class="chat-container">
    <div class="chat-users">
      <h3>Kontakty</h3>
      <?php foreach ($users as $u): ?>
        <div class="chat-user" data-id="<?= $u['id'] ?>">
          <img src="<?= htmlspecialchars($u['avatar'] ?: 'default-avatar.png') ?>" class="avatar-small">
          <span><?= htmlspecialchars($u['first_name'].' '.$u['last_name']) ?></span>
        </div>
      <?php endforeach; ?>
    </div>

    <div class="chat-box">
      <div id="chat-messages" class="chat-messages">
        <p>Wybierz użytkownika, aby rozpocząć rozmowę</p>
      </div>
      <form id="chat-form" style="display:none;">
        <input type="hidden" name="receiver_id" id="receiver_id">
        <input type="text" name="content" id="chat-input" placeholder="Napisz wiadomość..." autocomplete="off" required>
        <button type="submit">Wyślij</button>
      </form>
    </div>
  </div>
</section>

<script>
let activeUser = null;

// wybór kontaktu
document.querySelectorAll('.chat-user').forEach(u=>{
  u.addEventListener('click',()=>{
    activeUser = u.dataset.id;
    document.getElementById('receiver_id').value = activeUser;
    document.getElementById('chat-form').style.display='flex';
    loadMessages();
  });
});

// ładowanie wiadomości
function loadMessages(){
  if(!activeUser)return;
  fetch('messages_fetch.php?user_id='+activeUser)
  .then(r=>r.json())
  .then(data=>{
    const box=document.getElementById('chat-messages');
    box.innerHTML=data.map(m=>`
      <div class="msg ${m.sender_id==<?= $user['id'] ?>?'sent':'recv'}">
        <p>${m.content}</p><small>${new Date(m.created_at).toLocaleTimeString()}</small>
      </div>`).join('');
    box.scrollTop=box.scrollHeight;
  });
}

setInterval(()=>{ if(activeUser) loadMessages(); },3000);

// wysyłanie wiadomości
document.getElementById('chat-form').addEventListener('submit',e=>{
  e.preventDefault();
  const data=new URLSearchParams(new FormData(e.target));
  fetch('messages_send.php',{method:'POST',body:data})
  .then(()=>{e.target.reset();loadMessages();});
});
</script>

<?php include 'includes/footer.php'; ?>
